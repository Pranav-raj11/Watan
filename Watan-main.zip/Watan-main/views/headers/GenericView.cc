export module GenericView;

export class GenericView {
    // GameController* manager;
    public:
        GenericView() = default;
        virtual ~GenericView() = default;
};
