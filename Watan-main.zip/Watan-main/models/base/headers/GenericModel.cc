export module GenericModel;

import Randomness;

export class GenericModel {
    public:
        GenericModel();
        virtual ~GenericModel();
};

GenericModel::GenericModel() {}

GenericModel::~GenericModel() {}
